<section class="special-offer section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h2><?php echo e($title); ?></h2>
                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have
                        suffered alteration in some form.</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 col-md-12 col-12">
                <div class="row">
                    <?php if (isset($component)) { $__componentOriginald5bb25706eb24d48da67e36abde3a4ee = $component; } ?>
<?php $component = App\View\Components\SmartDevices::resolve(['title' => '','count' => '3'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('smart-devices'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SmartDevices::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5bb25706eb24d48da67e36abde3a4ee)): ?>
<?php $component = $__componentOriginald5bb25706eb24d48da67e36abde3a4ee; ?>
<?php unset($__componentOriginald5bb25706eb24d48da67e36abde3a4ee); ?>
<?php endif; ?>
                </div>
                <!-- Start Banner -->
                <div>
                    <?php if (isset($component)) { $__componentOriginal71f51d52f89b448d4600f1762a258d63 = $component; } ?>
<?php $component = App\View\Components\Samsung::resolve(['title' => '','count' => '1'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('samsung'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Samsung::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71f51d52f89b448d4600f1762a258d63)): ?>
<?php $component = $__componentOriginal71f51d52f89b448d4600f1762a258d63; ?>
<?php unset($__componentOriginal71f51d52f89b448d4600f1762a258d63); ?>
<?php endif; ?>
                </div>
                <!-- End Banner -->
            </div>
            <?php if (isset($component)) { $__componentOriginal5b9aaf157d0c1bd007811fb2f5be3907 = $component; } ?>
<?php $component = App\View\Components\SmartDevice::resolve(['title' => '','count' => '1'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('smart-device'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SmartDevice::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b9aaf157d0c1bd007811fb2f5be3907)): ?>
<?php $component = $__componentOriginal5b9aaf157d0c1bd007811fb2f5be3907; ?>
<?php unset($__componentOriginal5b9aaf157d0c1bd007811fb2f5be3907); ?>
<?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH F:\Khaled\سنة ثانية\فصل أول\قواعد بيانات الويب\تدريب لارافيل زيتونة\Training-at-Zaitouna\nawa-store\resources\views/components/smart.blade.php ENDPATH**/ ?>