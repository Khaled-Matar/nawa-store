
<?php $__env->startSection('content'); ?>
<header class="mb-4 d-flex">
    <h2 class="mb-4 fs-3"><?php echo e(('Deleted Products')); ?></h2>
    <div class="ml-auto">
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-sm btn-primary"> View Products</a>
    </div>
</header>
    <table class="table">
        <thead>
            <tr>
                <th></th>
                <th>ID</th>
                <th>Name</th>
                <th>Deleted at</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <td>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> 
                            <a href="<?php echo e($product->image_url); ?>">
                                <img src="<?php echo e($product->image_url); ?>" width="60" alt="">
                            </a>
                        </td>
                        <td><?php echo e($product->id); ?> </td>
                        <td><?php echo e($product->name); ?> </td>
                        <td><?php echo e($product->deleted_at); ?> </td>
                        <td>
                                <form action="<?php echo e(route('products.restore', $product->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-trash-restore"></i>
                                        Restore </button>
                                </form>
                        </td>
                        <td>
                            <form action="<?php echo e(route('products.force-delete', $product->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i>
                                  Force Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tbody>
    </table>
    <?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Khaled\سنة ثانية\فصل أول\قواعد بيانات الويب\تدريب لارافيل زيتونة\Training-at-Zaitouna\nawa-store\resources\views/admin/products/trashed.blade.php ENDPATH**/ ?>