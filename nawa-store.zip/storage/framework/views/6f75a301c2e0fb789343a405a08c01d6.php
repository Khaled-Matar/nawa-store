<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="single-banner right" style="<?php echo e($product->image_url); ?>">
        <div class="content">
            <h2><a href="<?php echo e(route('shop.products.show', $product->slug)); ?>"><?php echo e($product->name); ?></a></h2>
            <p><?php echo e($product->short_description); ?></p>
            <div class="price">
                <span><?php echo e($product->price_formatted); ?></span>
            </div>
            <div class="button">
                <a href="<?php echo e(route('shop.products.show', $product->slug)); ?>" class="btn">Shop Now</a>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH F:\Khaled\سنة ثانية\فصل أول\قواعد بيانات الويب\تدريب لارافيل زيتونة\Training-at-Zaitouna\nawa-store\resources\views/components/samsung.blade.php ENDPATH**/ ?>