<?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
    <a href="javascript:void(0)" class="remove"
        title="Remove this item"><i class="lni lni-close"></i></a>
    <div class="cart-img-head">
        <a class="cart-img" href="<?php echo e(route('shop.products.show', $item->product->slug)); ?>"><img
                src="<?php echo e($item->product->image_url); ?>"
                alt="Product image"></a>
    </div>

    <div class="content">
        <h4><a href="<?php echo e(route('shop.products.show', $item->product->slug)); ?>">
            <?php echo e($item->product->name); ?></a></h4>
        <p class="quantity"><?php echo e($item->quantity); ?><span class="amount"><?php echo e($item->product->price_formatted); ?></span></p>
    </div>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH F:\Khaled\سنة ثانية\فصل أول\قواعد بيانات الويب\تدريب لارافيل زيتونة\Training-at-Zaitouna\nawa-store\resources\views/components/cart.blade.php ENDPATH**/ ?>