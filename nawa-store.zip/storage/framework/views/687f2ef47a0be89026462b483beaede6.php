<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-12 col-12">
    <div class="offer-content">
        <div class="image">
            <a href="<?php echo e(route('shop.products.show', $product->slug)); ?>">
                <img src="<?php echo e($product->image_url); ?>" alt="#">
            </a>
            <span class="sale-tag">-50%</span>
        </div>
        <div class="text">
            <h2><a href="<?php echo e(route('shop.products.show', $product->slug)); ?>"><?php echo e($product->name); ?></a></h2>
            <ul class="review">
                <li><i class="lni lni-star-filled"></i></li>
                <li><i class="lni lni-star-filled"></i></li>
                <li><i class="lni lni-star-filled"></i></li>
                <li><i class="lni lni-star-filled"></i></li>
                <li><i class="lni lni-star-filled"></i></li>
                <li><span>5.0 Review(s)</span></li>
            </ul>
            <div class="price">
                <span><?php echo e($product->price_formatted); ?></span>
                <span class="discount-price"><?php echo e($product->compare_price_formatted); ?></span>
            </div>
            <p><?php echo e($product->short_description); ?></p>
        </div>
        <div class="box-head">
            <div class="box">
                <h1 id="days">000</h1>
                <h2 id="daystxt">Days</h2>
            </div>
            <div class="box">
                <h1 id="hours">00</h1>
                <h2 id="hourstxt">Hours</h2>
            </div>
            <div class="box">
                <h1 id="minutes">00</h1>
                <h2 id="minutestxt">Minutes</h2>
            </div>
            <div class="box">
                <h1 id="seconds">00</h1>
                <h2 id="secondstxt">Secondes</h2>
            </div>
        </div>
        <div style="background: rgb(204, 24, 24);" class="alert">
            <h1 style="padding: 50px 80px;color: white;">We are sorry, Event ended ! </h1>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH F:\Khaled\سنة ثانية\فصل أول\قواعد بيانات الويب\تدريب لارافيل زيتونة\Training-at-Zaitouna\nawa-store\resources\views/components/smart-device.blade.php ENDPATH**/ ?>