<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="col-lg-4 col-12">
    <div class="row">
        <div class="col-lg-12 col-md-6 col-12 md-custom-padding">
            <!-- Start Small Banner -->
            <div class="hero-small-banner"
                style="<?php echo e($product->image_url); ?>">
                <div class="content">
                    <h2>
                        <span>New line required</span>
                        <a href="<?php echo e(route('shop.products.show', $product->slug )); ?>"><?php echo e($product->name); ?></a>
                    </h2>
                    <h3><?php echo e($product->price_formatted); ?></h3>
                </div>
            </div>
            <!-- End Small Banner -->
        </div>
        <div class="col-lg-12 col-md-6 col-12">
            <!-- Start Small Banner -->
            <div class="hero-small-banner style2">
                <div class="content">
                    <h2>Weekly Sale!</h2>
                    <p><?php echo e($product->short_description); ?></p>
                    <div class="button">
                        <a class="btn" href="<?php echo e(route('shop.products.show', $product->slug )); ?>">Shop Now</a>
                    </div>
                </div>
            </div>
            <!-- Start Small Banner -->
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH F:\Khaled\سنة ثانية\فصل أول\قواعد بيانات الويب\تدريب لارافيل زيتونة\Training-at-Zaitouna\nawa-store\resources\views/components/second-product.blade.php ENDPATH**/ ?>