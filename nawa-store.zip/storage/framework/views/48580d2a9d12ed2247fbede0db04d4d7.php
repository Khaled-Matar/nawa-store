<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-6 col-md-6 col-12">
    <div class="single-banner" style="<?php echo e($product->image_url); ?>">
        <div class="content">
            <h2><a href="<?php echo e(route('shop.products.show', $product->slug)); ?>"><?php echo e($product->name); ?></a></h2>
            <p><?php echo e($product->short_description); ?></p>
            <div class="button">
                <a href="<?php echo e(route('shop.products.show', $product->slug)); ?>" class="btn">View Details</a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH F:\Khaled\سنة ثانية\فصل أول\قواعد بيانات الويب\تدريب لارافيل زيتونة\Training-at-Zaitouna\nawa-store\resources\views/components/smart-products.blade.php ENDPATH**/ ?>