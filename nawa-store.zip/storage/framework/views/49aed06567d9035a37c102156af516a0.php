<?php $__env->startSection('content'); ?>
    <header class="mb-4 d-flex">
        <h2 class="mb-4 fs-3"><?php echo e($title); ?></h2>
        <div class="ml-auto">
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-sm btn-primary"> + <i class="fas fa-trash"> Create User</i></a>
        </div>
    </header>
    <?php if(session()->has('success')): ?>
        <div id="success-message" class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <script>
        setTimeout(function() {
            var successMessage = document.getElementById('success-message');
            if (successMessage) {
                successMessage.style.display = 'none';
            }
        }, 5000);
    </script>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Change Password</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <td>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?> </td>
                        <td><?php echo e($user->name); ?> </td>
                        <td><a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-sm btn-outline-dark"><i
                                    class="far fa-edit"></i> Edit</a></td>
                        <td>
                            <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i>
                                    Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tbody>
    </table>
    <?php echo e($users->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Khaled\سنة ثانية\فصل أول\قواعد بيانات الويب\تدريب لارافيل زيتونة\Training-at-Zaitouna\nawa-store\resources\views/admin/users/index.blade.php ENDPATH**/ ?>