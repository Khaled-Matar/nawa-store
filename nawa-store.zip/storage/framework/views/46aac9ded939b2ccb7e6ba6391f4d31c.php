
<?php $__env->startSection('content'); ?>
<header class="mb-4 d-flex">
    <h2 class="mb-4 fs-3"><?php echo e(('Deleted Categories')); ?></h2>
    <div class="ml-auto">
        <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-sm btn-primary"> View Categories</a>
    </div>
</header>
    <table class="table">
        <thead>
            <tr>
                <th></th>
                <th>ID</th>
                <th>Name</th>
                <th>Deleted at</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <td>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> 
                            <a href="<?php echo e($category->image_url); ?>">
                                <img src="<?php echo e($category->image_url); ?>" width="60" alt="">
                            </a>
                        </td>
                        <td><?php echo e($category->id); ?> </td>
                        <td><?php echo e($category->name); ?> </td>
                        <td><?php echo e($category->deleted_at); ?> </td>
                        <td>
                                <form action="<?php echo e(route('categories.restore', $category->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-trash-restore"></i>
                                        Restore </button>
                                </form>
                        </td>
                        <td>
                            <form action="<?php echo e(route('categories.force-delete', $category->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i>
                                  Force Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tbody>
    </table>
    <?php echo e($categories->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Khaled\سنة ثانية\فصل أول\قواعد بيانات الويب\تدريب لارافيل زيتونة\Training-at-Zaitouna\nawa-store\resources\views/admin/categories/trashed.blade.php ENDPATH**/ ?>