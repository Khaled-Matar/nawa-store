<section class="hero-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-12 custom-padding-right">
                <div class="slider-head">
                    <!-- Start Hero Slider -->
                    <div class="hero-slider">
                        <!-- Start Single Slider -->
                        <?php if (isset($component)) { $__componentOriginalcde30343b5992b6d035d8930b2a71605 = $component; } ?>
<?php $component = App\View\Components\FirstsProduct::resolve(['title' => '','count' => '2'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('firsts-product'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FirstsProduct::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcde30343b5992b6d035d8930b2a71605)): ?>
<?php $component = $__componentOriginalcde30343b5992b6d035d8930b2a71605; ?>
<?php unset($__componentOriginalcde30343b5992b6d035d8930b2a71605); ?>
<?php endif; ?> 
                        <!-- End Single Slider -->
                    </div>
                    <!-- End Hero Slider -->
                </div>
            </div>
            
            <?php if (isset($component)) { $__componentOriginal09c9fb3ea088b6ceef368abf555b5d2d = $component; } ?>
<?php $component = App\View\Components\SecondProduct::resolve(['title' => '','count' => '1'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('second-product'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SecondProduct::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal09c9fb3ea088b6ceef368abf555b5d2d)): ?>
<?php $component = $__componentOriginal09c9fb3ea088b6ceef368abf555b5d2d; ?>
<?php unset($__componentOriginal09c9fb3ea088b6ceef368abf555b5d2d); ?>
<?php endif; ?> 
            
        </div>
    </div>
</section><?php /**PATH F:\Khaled\سنة ثانية\فصل أول\قواعد بيانات الويب\تدريب لارافيل زيتونة\Training-at-Zaitouna\nawa-store\resources\views/components/first-products.blade.php ENDPATH**/ ?>