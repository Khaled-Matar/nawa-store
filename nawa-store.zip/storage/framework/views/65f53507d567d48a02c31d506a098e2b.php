
<?php $__env->startSection('content'); ?>
    <header class="mb-4 d-flex">
        <h2 class="mb-4 fs-3"><?php echo e($title); ?></h2>
        <div class="ml-auto">
            <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-sm btn-primary"> + Create Category</a>
            <a href="<?php echo e(route('categories.trashed')); ?>" class="btn btn-sm btn-danger"> <i class="fas fa-trash"> View
                    Trash</i></a>
        </div>
    </header>
    <?php if(session()->has('success')): ?>
        <div id="success-message" class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <script>
        setTimeout(function() {
            var successMessage = document.getElementById('success-message');
            if (successMessage) {
                successMessage.style.display = 'none';
            }
        }, 5000);
    </script>

    <table class="table">
        <thead>
            <tr>
                <th></th>
                <th>ID</th>
                <th>Name</th>
                <th>Products #</th>
                <th>Products Avg Price</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <td>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e($category->image_url); ?>">
                                <img src="<?php echo e($category->image_url); ?>" width="60" alt="">
                            </a>
                        </td>
                        <td><?php echo e($category->id); ?> </td>
                        <td><?php echo e($category->name); ?></td>
                        <td><?php echo e($category->products_count); ?></td>
                        <td><?php echo e($category->products_avg_price); ?></td>
                        <td><a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn btn-sm btn-outline-dark"><i
                                    class="far fa-edit"></i> Edit</a></td>
                        <td>
                            <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i>
                                    Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tbody>
    </table>
    <?php echo e($categories->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Khaled\سنة ثانية\فصل أول\قواعد بيانات الويب\تدريب لارافيل زيتونة\Training-at-Zaitouna\nawa-store\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>