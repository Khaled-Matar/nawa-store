<section class="special-offer section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h2>{{ $title }}</h2>
                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have
                        suffered alteration in some form.</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 col-md-12 col-12">
                <div class="row">
                    <x-smart-devices title="" count="3" />
                </div>
                <!-- Start Banner -->
                <div>
                    <x-samsung title="" count="1" />
                </div>
                <!-- End Banner -->
            </div>
            <x-smart-device title="" count="1" />
        </div>
    </div>
</section>
