<section class="hero-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-12 custom-padding-right">
                <div class="slider-head">
                    <!-- Start Hero Slider -->
                    <div class="hero-slider">
                        <!-- Start Single Slider -->
                        <x-firsts-product  title="" count="2" /> 
                        <!-- End Single Slider -->
                    </div>
                    <!-- End Hero Slider -->
                </div>
            </div>
            {{-- // giving value to variabels  --}}
            <x-second-product  title="" count="1" /> 
            {{-- // giving value to variabels  --}}
        </div>
    </div>
</section>